def fibo(n):
    a=0
    b=1
    for x in range(n):
        a=bb=a+bprint(a,'\n')
        return b
        num=int(input('enter n'))
        print(fibo)
