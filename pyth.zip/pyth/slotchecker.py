table_slots=int(7) #number of slots to be filled in on table
#the firstin the table should deposit a certain amount and refer two others
user1=str(input("Input your name : \n")) #first user
rfrs=int(7)
for rfrs in range(0,7,+1):

     if(rfrs==0):
        user2 = input("enter name of your first refferall")
        print('remaining one')
     elif(rfrs==2):
            user3 = input("enter name of your second refferall")
            print('two refferalls completed successfully !!!! '+user1)
     elif(rfrs==1):
       user3 = input("enter name of your second refferall")
       print('complete ',user1)
     if(rfrs==3):         user4= input("enter name of your first refferall  " +user2)
     elif(rfrs==4):
         user5= input("enter name of your second refferall  "+user2)
     if(rfrs==5):
             user6= input("enter name of your first refferall "+user3)
     elif(rfrs==6):
        user7 = input("enter name of your second refferall  " + user3)
print(rfrs)

print('You have exhausted your reffers ..Congratullations!!!',user1)
print(rfrs)