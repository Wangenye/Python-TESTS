import string

for asu in range(0,26,+1):
    print(asu)
