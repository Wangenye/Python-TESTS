import math

print('checks the value of x when the equation is a(x^3)+/-b(x^2)+/-c(x)+/-k=0')
a=int(input("enter the value of a "))
b=int(input("enter the value of b "))
c=int(input("enter the value of c "))
k=int(input("enter the value of k "))
x=10
for x in range(-10,10,+1):
    result = a * (x **3) + b * (x **2) + c * (x) + k

    if(result==0):
        print("x = ",x )


input("press enter to exit")
    # print(x)
    # if(result==0):
    #     result = a * (x * x * x) + b * (x * x) + c * (x) + k
    #     print(x)

