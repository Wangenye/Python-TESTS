import os

name=str(input('enter name : \n'))

if(name=='sim'):
    os.mkdir('C:/Users/SIMON/Desktop/simsd')
    bo = open('C:Users/SIMON/Desktop/simsd/b.txt', 'w')