import os
import time
import calendar

usres=[]
default_amount=int(500)

def number1():
	pass

usres.append('user1')
user1=str(input('Enter name : \n'))
amount_to_deposit=int(input("Enter Amount to deposit: \n"))
no_of_slots=int(amount_to_deposit/default_amount)
print(no_of_slots)
print(time.asctime())


def reffer_of_user_one():
    pass
print('Enter your reffers ',user1)
usres.append('user2')
user2=str(input('Enter name : \n'))
if(len(user2)<=3):
    print('please input a valid name')
else:
    usres.append('user3')
user3=str(input('Enter name : \n'))
if(len(user3)<=3):
    print('please input a valid name')
else:
    amount_to_deposit+=amount_to_deposit+amount_to_deposit
print('Amount to Deposit : ',amount_to_deposit)
#no_of_slots=int(amount_to_deposit/default_amount)
# print(time.asctime())
if(len(usres)<=3):
    print(user1, 'Reffered : ',"\n", user2,'\n', user3)
else:
    print(user1," please finish up refferring two")