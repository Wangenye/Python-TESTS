# import calendar
# print(calendar.isleap(2010))

from subprocess import call

call(["open",",1.jpg"])