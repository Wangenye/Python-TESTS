'''from math import sqrt
# Get value from the user
num = eval(input("Enter number: "))
# Compute the square root
root = sqrt(num)
# Report result
print("Square root of", num, "=", root)'''

def hell0_func():
    return '{} Function'.format(greeting)
print(hell0_func('hi'))