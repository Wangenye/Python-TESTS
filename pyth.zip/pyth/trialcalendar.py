#import calendar

#print(calendar.calendar(2018,110))
#graphical user interface

from _tkinter import *

a = TK()
a.title("my first window")
