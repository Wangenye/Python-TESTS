string1="python"
string2="tutorial"

#concatenation
print(string1+string2)
#repetation
print(string2*4)
#slicing
print(string2[1:4])
#indexing
print(string1[-3]+string2[3])
print(string1.count('p',0,5))
print(string2.find('i'))
print(string2.isalpha())
