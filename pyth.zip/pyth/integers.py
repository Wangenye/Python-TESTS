import math
import random

print(math.log(9))
print ("min(80, 100, 1000) : ", max(80, 100, 1000))
print ("returns a random number from range(100) : ",random.choice(range(100)))

from random import randint

print(randint(0,1000000))

5 in [1,3,6]