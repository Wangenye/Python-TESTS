print("please input value of x")
x=int(input())
print("input y")
y=int(input())

print("z",x+y)
