print('please enter your marks')
marks=int(input())
#marks=int

if(marks>80):
    print("grade:a")
elif(marks>60) and (marks<=80):
    print('grade=B')
elif(marks>40) and (marks<=60):
    print('grade:C')
else:
    print("grade:C")