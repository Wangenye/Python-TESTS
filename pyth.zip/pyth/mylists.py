my_list=['green','pink','yellow','blue']


#append
my_list.append('grey',)
print(my_list)

#extend
my_list.extend(['maroon','white'])
print(my_list)

