#while loop
'''num=int(input("enter value of n="))

if(num<=0):
       print('enter a valid number')
else:
    sum=0b
    while(num>0) and (num<10):
        sum+=num
        num+=1
        print(sum)'''
#for loop statement
for quant in range(4,0,-1):
    if quant>1:
        print(quant,"Bottles of beer on the wall", quant ,"Bottles of beer on the wall")
        if quant>2:
            suffix=str(quant)+ "Bottles of beer on the wall"
        else:
            suffix="1 Bottle of beer on the wall"
    elif quant==1:
        print("1 Bottle of beer on the wall,1 Bottle of beer ")
        suffix="no moore beer on the wall"
        print("take one down and pass it around",suffix)

        print("-----")

