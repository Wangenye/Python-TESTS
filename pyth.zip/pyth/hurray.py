from tkinter import *
a=Tk()
a.title("my first window")
root=tkinter.Tk()
root.title("second window")
