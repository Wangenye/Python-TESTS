bo = open('C:Users/SIMON/Desktop/b.txt','w')
bo.write('this is the file i want to use in python'
         'helloooooo everyone ')
bo=open('d:/b.txt','r')
print(bo.read())