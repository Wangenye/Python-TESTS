#CLASS AND OBJECT
class student:
    def details(self,name,age):
        self.name=name
        self.age=age
        print("The name ia {} and age is {} ".format(name,age))
        s=student()
        print(s.details(name,age))