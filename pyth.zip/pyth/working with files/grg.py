name=input("enter name")
print(name)
num1=int(input("enter num1\n"))
num2=int(input("enter num\n"))

print(num1+num2)
print(4+5)