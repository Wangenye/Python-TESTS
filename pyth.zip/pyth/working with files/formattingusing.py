#formatting using print function
name='peter'
age=35
per=65.9
#print("the name is", name, "age is", age," percentage is",per)
print("the name is %s the age is %.0"
      "f the percentage is %d "%(name,age,per))



