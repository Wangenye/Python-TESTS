num1=float(input('enter num1'))
num2=float(input('enter num2'))
try:
 num3=float(num1/num2)
except:
 print('no division by zero')
else:
    print(num3)

