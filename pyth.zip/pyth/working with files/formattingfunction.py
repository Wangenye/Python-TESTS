n="peter"
a=25
print("Name is %s and age is %s"%(n,a))


print("Name is {} and age is {:6}".format(n,a))

for i in range(1,11):
    print("{:3}{:3}{:6}".format(i,i*i,i*i*i))