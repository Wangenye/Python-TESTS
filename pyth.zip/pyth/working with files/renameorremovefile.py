import os# it is the module we import fo the file functions

# os.rename('d:/b.txt','d:/bmk.txt')#renaming a file
os.remove('d:/bmk.txt')#removing a file