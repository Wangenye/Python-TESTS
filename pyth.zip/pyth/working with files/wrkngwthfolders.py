# import os
# # os.mkdir('d:/sim')#.mkdir isused t create a directory/folder
# print(os.getcwd()) # the function used to check the path of a directory/file
# # os.chdir('d:/audio//simeon')
import os

os.mkdir('C:/Users/SIMON/Desktop/sim')