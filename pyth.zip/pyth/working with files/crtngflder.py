import os

os.mkdir('C:/Users/SIMON/Desktop/sim')