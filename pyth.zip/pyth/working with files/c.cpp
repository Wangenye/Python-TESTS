#include<stdio.h>
#define r 0.1
void main()
{
    double a,p;
    int a,c;

    printf("\n input the principal amount");
    scanf("%f",&p);
    printf("\n input the number of years");
    scanf("%d",&n);

    double q=1;

    for(c=1;c<=n;c++)
    {
        q=q*(1+r);
        a=p*q;

        printf("\n amount = %",a);

    }
}