users=['user1','user2','user3','user4','user5','user6','user7']
amount=500
maintainance=50
cashout=''
reffers=2
members=7
user1=str(input("enter name"))
if(len(user1)<3):
    print('enter valid name')

# print(len(user1))
'''users[0]=str(input("Input your Name : \n"))
cash_in=int(input("enter amount to Cash in :\n"))

if(cash_in==500):
    print("welcome "+users[0])
else:
    print("deeposit 500")

print(users[0])
if(cash_in==500):
    user_to_reffer=int(input("enter number of usres to refer"))
   
users[1] = str(input('enter name\n'))
    users[2]=str(input('enter name\n'))
    if (reffers == user_to_reffer):
        print("Congratulations" + users[0], "you reffered", users[1], users[2])
    else:
        print("complete reffers first")'''


