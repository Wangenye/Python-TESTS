'''my_set={1,2,3,4,5,6,2,1,1}
print(my_set)'''

#metohods
#union
mys1={1,2,5,7,5,10,8,2,1}
mys2={2,5,9,11,15,20}
 
print(mys1|mys2)

print(mys1-mys2)

print(mys1&mys2)