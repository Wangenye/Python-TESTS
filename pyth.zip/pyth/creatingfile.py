name=input('enter name')
age=int(input('enter age'))

print('name is {} and age is {}'.format(name,age))

input(" press enter to quit")
