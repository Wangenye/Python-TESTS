def simon():
    print("enter any number")

    simon()
    num1=int(input())

    simon()
    num2 = int(input())
    sum=num1+num2;
    print(sum)
