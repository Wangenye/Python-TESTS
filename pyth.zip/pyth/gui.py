import tkinter
top=tkinter.Tk()
top.mainloop()
