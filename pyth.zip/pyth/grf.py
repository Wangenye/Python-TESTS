#defination=['name','nickname']

users=["user1","user2","user3","user4","user5","user6","user7"]
default_amount=int(500)

#print(len(users))

#if(users==users[0]):
user1=input('Please enter name\n')
amount=int(input('Enter amount to deposit'))
