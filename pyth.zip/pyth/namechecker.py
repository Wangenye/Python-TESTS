names=[]
reffer=[]
default_amount=int(500)
names.append("User1")
#if(len(names)==1):
user1=str(input("Please input name : \n"))
amount=int(input("Amount to cash in : \n"))
slots=int(amount/default_amount)
#if(names[0]==1):
names.append("user2")
print("Please reffer  others : \n")

user2=str(input("Enter Name : \n"))

names.append("user3")
user3=str(input("Enter Name : \n"))

amount_deposited=amount+amount
''''if(len(names)==3):
    print("Name : ", user1)
    print(user1+ " ,Your slots are full \nYou reffered ", user2,"\n", user3)
    print("Amount deposited : ",amount_deposited+amount)
elif(names[0]==2):
    print(user2'''
