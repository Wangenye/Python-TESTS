my_dict={1:'green',2:'blue'}
#print(my_Dict)


        #DICTIONARY METHODS
#i)Accessing dictionary

print(my_dict[2])
#ii)length
print(len(my_dict))
#iii)key
print(my_dict.keys())

#value
print(my_dict.values())
#update
my_dict.update({3:'udemy',4:'ulemy'})
print(my_dict)