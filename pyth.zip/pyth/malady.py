'''name=str(input('enter name of your lady\n'))

if(name=='vero'):
    print(name,  'is simons lady from magadi')
else:
    print('not known')'''
radius=int(input('enter the radius of your circle\n'))
pi=float(3.14)
if(radius>0):
    area=radius*radius*pi
    print('area=', area)
else:
    print('enter valid radius')
