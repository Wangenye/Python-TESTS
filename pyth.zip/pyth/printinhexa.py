print("simon",end='')
print("simon",end='')
print("simon",end='')
print()
print('mugo')
print('mugo')
print('mugo')
w,x,y,z=10,20,30,40
print(w,x,y,z)
print(w,x,y,z,sep=',')
print(w,x,y,z,sep='')
print(w,x,y,z,sep='--------')


