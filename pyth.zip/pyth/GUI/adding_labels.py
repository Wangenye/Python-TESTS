from tkinter import *

myGui = Tk()

two = Tk()

def hello():
    b= a.get()
    myLabel2 = Label(text=b,fg="yellow",bg="green").pack()

def dele():
    myLabel1 = Label(text='DELETED !!',fg="yellow",bg="green").pack()
def show():
    print("THE TEXT IS :",a)
a = StringVar()
myGui.title("ADDING LABELS !!")
two.title("SECOND WINDOW !!!")


myGui.geometry("500x500+100+100")
two.geometry("500x500+100+100")

myLabell = Label(text='LABEL ONE !!',fg="yellow",bg="green",font=10).pack()
# myLabel1 = Label(text='LABEL TWO !!',fg="yellow",bg="green").pack()
# myLabel2 = Label(text='LABEL THREE !!',fg="yellow",bg="green").pack()
# myLabell.pack()

myObject =Button(text ='ENTER !',bg='white',fg='black',command=hello,font=20).pack()
myDel = Button(text='DELETE !',fg='white',command=dele,font=20).pack()
shoWtext = Button(text='SHOW TEXT',command=show).pack()

text = Entry(textvariable=a).pack()

myGui.mainloop()