# from tkinter import *
#
# myGui=Tk()
# myGui.title("hello")
# myGui.geometry("500x500+100+100")
# myGui.mainloop()

#a=Tk()
#a.title("my first window")
#a.mainloop()


#ADDING LABELS TO WINDOWS

from tkinter import *

myGui=Tk()
myGui.title("hello")
myGui.geometry("500x500+100+100")
myLabel1=Label(text='helloo simeon',fg='yellow',bg='green').pack()
myButton= Button(text='Enter').pack()

# myLabel1.pack()
myGui.mainloop()


