from tkinter import *

example =Tk()
example.geometry("500x500+100+100")
example.title("First succesfull window")
hello= Button(text='helloo',activebackground='red',justify=CENTER).pack()

example.mainloop()

from tkinter import *
from tkinter import messagebox
top = Tk()
top.geometry("500x500+100+100")
def helloCallBack():
    k = messagebox.showinfo("Hello Python", "Hello World")

B = Button(top, text ="Hello", command = helloCallBack)
B.place(x=50,y=50)
top.mainloop()