import tkinter

root = tkinter.Tk()
root.title("second")
root.mainloop()