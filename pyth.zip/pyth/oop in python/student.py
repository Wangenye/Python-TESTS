class student:
    def __init__(self, name, major, gpa, is_on_probition):
        self.name=name
        self.major=major
        self.gpa=gpa
        self.is_on_probition=is_on_probition