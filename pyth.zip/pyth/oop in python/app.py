from constructormethod import simon
student=simon()
print(student.details("simeon",45))


# from student import  student
# student1=student("jim","BUSINESS",3.1,False)
#
# print(student1.major)
# # from craetingclass import student
#
# # s2=student()
# # print(s2.details("xssgxgf",34))
#
#
# # for i in range(1,6,+1):
# #     print('\n')
# #     for j in range(1,6,+1):
# #
# #         print("",i*j)
