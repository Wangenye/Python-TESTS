class simon:
    def details(self,name,age):
        self.name=name
        self.age=age
        print("the name is {}  and age is {} ".format(name,age))

    def __init__(self):
        print("welcome ")