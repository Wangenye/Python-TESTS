class student:
    def details(self,name,age):
        self.name=name
        self.age=age
        s1=student()
        print(s1.details("collin",32))

        #print("name is {} and age is {} ".format(name,age))
