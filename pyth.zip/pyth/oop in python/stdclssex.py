class student:
    def __init__(self,name):
        self.name=name
        self.attendance=0
        self.marks=[]
        print(" welcome {} to this xchool".format(name))

        s1=student("peter")