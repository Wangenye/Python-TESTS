# class student:
#     def __init__(self): details(self,name,age):
#         print("thename is {} and the age is {}".format(name,age))
#         stud = student()
#         print(stud.details("hugo",56)
#               return
class student:
    def __init__(self, name, major, gpa, is_on_probition):#__init__:is a constructor function method
        self.name=name   #
        self.major=major
        self.gpa=gpa
        self.is_on_probition=is_on_probition