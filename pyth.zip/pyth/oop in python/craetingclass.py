class student:
    def details(self,name,age):
        print("the name is {} and age is {} ".format(name,age))

        s2 = student()
        print(s2.details("xssgxgf", 34))