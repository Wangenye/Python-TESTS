
print('text')
employee_name=str(input('please enter your name\n'))
hours_worked=float(input('input hours worked\n'))
rate_of_pay=1000
rate_of_taxation=0.11
'''while(hours_worked>=15):
        print('CONGRATULATIONS!!! you won a ticktet, A free holiday')'''
if(hours_worked>=1):
    gross_pay=hours_worked*rate_of_pay
    taxation=gross_pay*rate_of_taxation
    net_pay=gross_pay-taxation

    print('NAME: ',employee_name,'\nNET PAY :',net_pay,'\nHOURS WORKED :',hours_worked,'\nGROSS PAY :',gross_pay)
elif(hours_worked<1):
   minutes_worked=float(input('Enter minutes worked'))
   hours_worked=minutes_worked/60
   print(hours_worked)
   to_do=str(input('should we calculate\n'))
   if(to_do=='yes'):
       gross_pay = hours_worked * rate_of_pay
       taxation = gross_pay * rate_of_taxation
       net_pay = gross_pay - taxation
       print('NAME: ', employee_name, '\nNET PAY :', net_pay, '\nHOURS WORKED :', hours_worked, '\nGROSS PAY :',gross_pay)

if(hours_worked>=15 and hours_worked<25):
    print('CONGRATULATIONS!!! you won a ticktet, A free holiday')
elif(hours_worked>=25 and hours_worked<=35):
    print("\033[2;32;10m yoou won ksh.1500",gross_pay+1500)
else:
    bonus=15000
    print("\033[2;32;10 you won ksh.15000", gross_pay + 15000)

'''else:
    print('Dear ',employee_name,' please work for atleast an hour')'''

input('press enter to quit')

