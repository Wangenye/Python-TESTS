def hello_func():
    pass
print('efasgfsdgf')
hello_func()