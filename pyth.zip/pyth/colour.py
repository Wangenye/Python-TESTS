print("\033[1;32;10m ]")
print("\033[1;32;10m yoou won ksh.1500")