#arithimetic operators
'''num1=10
num2=20
print("num1 + num2=",num1+num2)
print("num1 - num2=",num1-num2)
print("num1 * num2=",num1*num2)
print("num1 / num2=",num1/num2)
print("5^3=",5**3)
print("20%3=",20%3)
print("22//7=",22//7)
#assignment operators
num3=num1+num2
print(num3)
num3+=num2
print(num3)
#comparison operator
print("is nu3>num2",num3>num2)
print("is num2=num3",num2==num3)
print("is num1!=num2",num1!=num2)
#logical operators
x=True
y=False

print("x and y",x and y)
print("x or y",x or y)
print("not of y",not y)'''
#bitwise operators
"""num4=6   #110
num5=2   #010

print("bitwise and=",num4 & num5)
print("bitwise or=",num4 | num5)
print("bitwise xor=",num4 ^ num5)
print("num4 right shift by 2", num4 >> 2)
print("num5 left shift by 2",num5 << 2)
#membership operators"""
#string sequence operations
string1="python"
string2="tuorial"

        #concantenationprint(string1+string2)




num4=6   #110
num5=2   #010

print("bitwise and=",num4 & num5)
print("bitwise or=",num4 | num5)
print("bitwise xor=",num4 ^ num5)
print("num4 right shift by 2", num4 >> 2)
print("num5 left shift by 2",num5 << 2)
#membership operators
