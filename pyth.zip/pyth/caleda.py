import calendar
print(calendar.year(2018))
