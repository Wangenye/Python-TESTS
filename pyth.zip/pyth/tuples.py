'''my_tup=('simon','john','mwangi','mugo')

#conatenation

print(my_tup+('ron','sanjay'))

#repetation
print(my_tup*2)

#slicing
print(my_tup[1:2])
#indexing'''

def fibo(k):
    a=0
    b=1
    for x in range(k):
        a=bb=a+b
        print(a,'\n')
        return b
    num=int(input('enter value of n'))
    print(fibo(num))