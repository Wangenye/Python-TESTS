import time

for a in range(1,11):
    input()
    # time.sleep(2)
    print('\n')
    for b in range(1,11):
        print(a,'x',b,'=',a*b)