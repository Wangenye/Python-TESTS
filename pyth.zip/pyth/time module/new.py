import time
# n=int(input('enter number'))
# fact=1
# if(n==0):
#     fact = 1
# else:
#     for n in range(1,n,):
#         fact = n * fact
#
#     print('factorial = ', fact)
#
#
#
#
# # fact=n * (fact*(n-1))
# #
# # print(fact)
for i in range(1,10,+1):
    time.sleep(2)
    for j in range(1,11,+1):
        print(i,"X",j, "=",i*j)
