import calendar

print(calendar.calendar(2018,1,2,10))