import time

print('image1')
time.sleep(3)
print('image2')
time.sleep(3)
print('image3')

for a in range(1,11):
    time.sleep(4)
    print('\n')
    for b in range(1,11):
        print(a,'*',b ,'=' ,a*b)