import time

tl=time.time()
print(tl)
print(time.asctime())
print(time.localtime(tl))