import calendar as calendar

import time

c=calendar.TextCalendar(calendar.Sunday)
str=c.formatmonth(2025,1)
print(str)