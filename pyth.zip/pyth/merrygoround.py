'''user=str(input("please enter your name\n"))
amount=int(input("enter amount to deposit\n"))

if(amount==500 or amount==1500 or amount==2000 or amount==2500):
    print("\033[1;32;10m Congratulations", user,"!!! You deposited" ,amount)
else:
    print('amount should be 500 OR 1000 OR 1500 OR 2000 OR 2500')'''
myusers={'user1','user2','user3','user4','user5','user6','user7'}

user=str(input("Enter name\n"))
amount=int(input("Enter your plan\n"))
fixed=amount
if(amount==500 or amount==1000 or amount==1500 or amount==2000 or amount==2500):
    print("\033[1;32;1mCongratulations", user,"!!! You deposited""" ,amount)
else:
    print('amount should be 500 OR 1000 OR 1500 OR 2000 OR 2500')

#reffers
prompt=print("Please reffer two others\n")
''''user2=str(input("NAME : "))
user3=str(input("NAME : "))'''
refferalls=2
for refferalls in range(0,2,+1):
   users=str(input("NAME : "))

  # break
#users=str(input("NAME : "))
amount+=amount
print("amount to deposit = ", amount)




